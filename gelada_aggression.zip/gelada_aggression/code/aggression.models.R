####################################
## Aggression Models 
## last updated: 7 June 2023 
## written by: Julie Jarvey 
## contributions ISC Oct 2022, May 2023
## contributions KLC May 2023 
####################################

# Setup ------------------------------------------------------------------------

rm(list = ls()) 

library(tidyr)
library(dplyr)
library(lme4)
library(visreg)
library(ggplot2)
library(sjmisc)
library(sjPlot)
library(bbmle)
library(lattice)
library(lubridate)
library(ggeffects)
library(ggpubr)

# load data
load("data/scans.aggressions.elo.RData")

# subset to within-unit aggression only
within <- scans.aggressions %>%
  filter(agg.rec.type == "W")

# relevel context variable
within$new_context = as.factor(within$new_context)
within$new_context = relevel(within$new_context, ref = "FeFo")

# model ------------------------------------------------------------------------
mW.rain <- glmer(agg.rec.binary ~ Elo.standardized*new_context + scale(Rain30) +
              (1|ID/Unit), family=binomial, data=within,
            control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=2e5)))

# summarize
summary(mW.rain)

# additional models for SI -----------------------------------------------------

# combine move and rest into one state
within$Context4 <- as.character(within$Context)
within$Context4[within$Context == 'Rest'| within$Context == 'Move'] <- 'NS'
within$Context4 <- factor(within$Context4, levels = c('FA', 'NS', 'FB', 'Social'))

# S2
mW.rainS2 <- glmer(agg.rec.binary ~ Elo.standardized*Context4 + scale(Rain30) +
                   (1|ID/Unit), family=binomial, data=within,
                 control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=2e5)))

# summarize
summary(mW.rainS2)

# S3
mW.rainS3 <- glmer(agg.rec.binary ~ Elo.standardized*Context + scale(Rain30) +
                     (1|ID/Unit), family=binomial, data=within,
                   control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=2e5)))

# summarize
summary(mW.rainS3)

# model predictions ------------------------------------------------------------
# bootstrap to get confidence intervals
result_list_rain = lapply(1:1000,function(i) {
  within_resample = within[sample(1:nrow(within), replace = T),]
  mW_resample <- glmer(agg.rec.binary ~ Elo.standardized*new_context  + scale(Rain30) +
                         (1|ID), family=binomial, data=within_resample,
                       control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=2e5)))
  df_resample = ggpredict(mW_resample, terms = c("Elo.standardized [all]", "new_context"), ci.lvl = 0.95)
  predictions_resample = with(df_resample,data.frame(x,group,predicted,iteration=i))
  return(predictions_resample)
})

# generate and format list of bootstrapping results
results_df_rain = do.call(rbind,result_list_rain)
results_df_stats_rain = do.call(rbind,lapply(split(results_df_rain,with(results_df_rain,list(x,group))),function(this) {
  ci = quantile(this$predicted,c(0.025,0.975))
  data.frame(x = unique(this$x),group=unique(this$group),pred.lower = ci[1],pred.upper=ci[2])
}))

# predicted values
df_rain = ggpredict(mW.rain, terms = c("Elo.standardized [all]", "new_context"), ci.lvl = 0.95)
within_results_rain = with(df_rain,data.frame(x,group,predicted))

# predicted values
df_rain = ggpredict(mW.rain, terms = c("Elo.standardized [all]", "new_context"), ci.lvl = 0.95)
within_results_rain = with(df_rain,data.frame(x,group,predicted))

# plots ------------------------------------------------------------------------------
states <- c('Feeding Belowground','Moving/Feeding Aboveground',  'Social/Resting')

# change factor levels
df_rain$group2 <- factor(df_rain$group, levels = c('FB', 'FeFo', 'SoRo'))
results_df_stats_rain$group2 <- factor(results_df_stats_rain$group, levels = c('FB', 'FeFo', 'SoRo'))

# plot predicted values with bootstrapped CIs
pred.plot <- ggplot() +
  geom_ribbon(data=results_df_stats_rain,aes(x,ymin=pred.lower*100,ymax=pred.upper*100,fill=group2),alpha=0.07) + 
  geom_line(data = df_rain, aes(x, predicted*100, col = group2)) + theme_classic() +
  theme_classic(base_size = 20) +
  theme(legend.title=element_blank(), legend.position=c(0.75,0.9)) +
  ylab("Probability of receiving aggression (%)") + xlab("Standardized rank") +
  scale_color_manual(values=c('#fc7d0b','#1170aa', '#a3acb9'),name='',labels=states) +
  scale_fill_manual(values=c('#fc7d0b','#1170aa', '#a3acb9'),name='',labels=states) +
  ggtitle("") + 
  coord_cartesian(ylim=c(0,35))

pred.plot

# save plot
ggsave(filename = 'figures/pred.plot.png', pred.plot, scale = 1, width = 8, height = 6,
       units = 'in')


# plot model estimates in forest plot  
# within unit
wthn.agg.rain <- plot_model(mW.rain, type = 'est', title = "") +
  theme_classic() + scale_y_continuous(trans='log2', limits = c(0.0625,4), breaks = c(0.125, .25, .5, 1, 2, 4), labels = seq(-3, 2, 1)) 

wthn.agg.rain = wthn.agg.rain + geom_hline(yintercept=1.0, linetype='dashed', color='grey70', size=1) + 
  scale_color_manual(values = c("#9933CC", "#9933CC")) +
  scale_x_discrete(labels = c('Elo:Social/Resting', 'Elo:Belowground Feeding', 'Rain (30-day)', 'Social/Resting', 'Feeding Belowground', 'Elo Rating'))  + 
  coord_flip(ylim = c(0.18, 4)) + theme_classic(base_size = 20) + ylab(expression(Log[2]~"Odds Ratio")) 

wthn.agg.rain 

ggsave(filename = 'figures/forest.plot.png', wthn.agg.rain, scale = 1, width = 8, height = 6,
       units = 'in')
