#################################################
## Aggression Models  - using only displacements
## last updated: 7 June 2023 
## written by: Julie Jarvey 
## contributions ISC 8 Aug 2022
################################################

# Setup ------------------------------------------------------------------------

rm(list = ls()) 

library(tidyr)
library(dplyr)
library(lme4)

# load data

load("data/scans.agg/scans.displacements.elo.RData")

# subset within-unit aggression
within <- scans.displacements %>%
  filter(agg.rec.type == "W")

# run model (S4 in Supplementary Information) ----------------------------------

mW.d <- glmer(agg.rec.binary ~ Elo.standardized * Context2 + rain30.scaled +
                 (1|Unit/ID), family=binomial, data=within,
                 control=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=2e5)))

summary(mW.d)

